package com.example.supportblock.mixin;

import java.util.function.DoubleSupplier;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.debug.SupportBlockRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Filters the visualize_entity_supporting_block debug renderer so that only
 * OTHER players get a supporting-block highlight. The local player, mobs,
 * items and every other entity are skipped.
 */
@Mixin(SupportBlockRenderer.class)
public abstract class SupportBlockRendererMixin {

	/**
	 * drawHighlights(Entity, DoubleSupplier, int) is called once per entity
	 * that the renderer wants to highlight. Cancelling it at HEAD means
	 * nothing is drawn for that entity.
	 */
	@Inject(method = "drawHighlights", at = @At("HEAD"), cancellable = true)
	private void opsb$onlyOtherPlayers(Entity entity, DoubleSupplier dilation, int color, CallbackInfo ci) {
		boolean otherPlayer = entity instanceof Player && entity != Minecraft.getInstance().player;
		if (!otherPlayer) {
			ci.cancel();
		}
	}
}
